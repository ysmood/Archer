<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <style>
        h3, h4
        {
            font-family: Georgia;
        }
        
        h4
        {
            margin-left: 20px;
        }
    </style>
	<title>Plus Game</title>
</head>
<body>
    <h3>Choose Role:</h3>
	<h4><a href="./?p=0">Player Blue</a></h4>
	<h4><a href="./?p=1">Player Red</a></h4>
	<h4><a href="./plus_game_source.zip">Source Code.zip</a></h4>
    <p>Game Rule : Add one of your number to your partner's. Who first get two 9s who wins.</p>
</body>
</html>